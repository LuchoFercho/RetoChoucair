package RetoChoucair1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.By;

public class StepDefinition {
	
	WebDriver driver = new ChromeDriver();
	WebDriverWait wait = new WebDriverWait(driver,7);
	
	@org.junit.BeforeClass
	public void BeforeClass() {
		System.setProperty("webdriver.chrome.driver","./src/test/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
		
	}
	

	@Given("Estoy en la pagina de inicio de sesion de la pagina")
	public void estoy_en_la_pagina_de_inicio_de_sesion_de_la_pagina() {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","./src/test/chromedriver/chromedriver.exe");
		//driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
		WebElement loginbox = driver.findElement(By.className("login"));
		loginbox.submit();
		wait.withTimeout(null);
	    System.out.println("abriendo pagina de login");
	}

	@When("Ingreso correo {string} y contrasena {string}")
	public void ingreso_correo_y_contrase_a(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		//WebDriver driver;
		//driver = new ChromeDriver();
		WebElement emailbox = driver.findElement(By.id("email"));
		WebElement passbox = driver.findElement(By.id("passwd"));
		emailbox.sendKeys(string);
		passbox.sendKeys(string2);
		passbox.submit();
		wait.withTimeout(null);
		System.out.println("ingresando credenciales"+ string+","+ string2 );
	}

	@When("Doy Click en aceptar")
	public void doy_click_en_aceptar() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Dando Click en Aceptar");
	}

	@Then("Ingreso en mi perfil en la pagina")
	public void ingreso_en_mi_perfil_en_la_pagina() {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(driver.findElement(By.className("account")).getText(),"Luis Rosero");
		System.out.println("Estoy en mi perfil de la pagina");
	}
}
